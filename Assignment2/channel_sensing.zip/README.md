## How to run
Place the files in `contiki-ng/exercises/channel_sensing/`

```bash
make TARGET=sky MOTES=/dev/ttyUSB0 channel_sensing.upload
make TARGET=sky MOTES=/dev/ttyUSB0 login 
```
